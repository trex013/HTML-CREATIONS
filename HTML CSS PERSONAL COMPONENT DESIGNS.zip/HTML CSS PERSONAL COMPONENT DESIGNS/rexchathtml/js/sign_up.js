$(document).ready(function(){
var form = document.forms['signUp'];

//alert(forms);
var pass = form["pass"],
rpass = form["rpass"];

$("#passcheck").on("blur",function(){
    console.log(pass.value.length)
    if (pass.value != rpass.value ){
        $("#passcheck").after("<div>error!: No match</div>");
        console.log("passcheck failed");
    } else {
        if (pass.value.length < 8){
            $("#passcheck").prev().after("<div>password too short</div>");
        } else {
                $("#signUp").on("click",function(){
            console.log(form['accept'].checked);
            if (form['accept'].checked){
                console.log("working");
                form['submit'].setAttribute('type','submit');
                //$("[type = 'button']").attr("type","submit");
            } else {
                form['submit'].setAttribute('type','button');
                //alert("Read Terms and conditions and check button");
            }
            //$('#signUp').on('submit')
            });
        }
    }
});
$("#select-cover").on("click", function(){
    $("::after").css({"content":"u"});
});

    //alert($("option:nth-child(3)").val());
    $("option:nth-child(n)").css({
        "background-color": "white",
        "color":"orange",
    });
});
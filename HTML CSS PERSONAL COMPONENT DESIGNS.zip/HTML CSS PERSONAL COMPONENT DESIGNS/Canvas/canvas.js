
logs = {}

function log(x, val = ""){
    logs[val] = x
    console.log(logs)
}

var rand = function(x) {
    return Math.random() * x;
}


// 1362
//
var drawBoard = document.querySelector("canvas");
var p = drawBoard.getContext("2d");

drawBoard.width = window.innerWidth - 4//the 4 is for the border
drawBoard.height = window.innerHeight - 4;



//line
// p.beginPath()// Strat the line drawing
// p.strokeStyle = "green"
// p.moveTo(20, 40)// Starting point
// p.lineTo(200,200)// to point
// p.lineTo(100,250)
// p.stroke()// draws the line

/* if you use a strokeStyle,
you must use .stroke() to fill it
*/

// Rectangle
// p.beginPath()
// p.fillStyle = "rgba(60,60,60,.5)"
// p.fillRect(20,20, 100,100)

function Circle(x, y, r, dx, dy) {
    this.x = x
    this.y = y
    this.dx = dx
    this.dy = dy
    this.r = r

    this.draw = function(){
        p.beginPath()
        p.strokeStyle = "blue"
        p.arc(this.x,this.y,this.r, 0, Math.PI * 2, false)
        p.stroke()
    }
    
    
}
//Arc
var x = rand(innerWidth), y = rand(innerHeight);
var dx = (Math.random() - 0.5) * 9, dy = (Math.random() - 0.5) * 9;
var r = 60
function anime() {
    requestAnimationFrame(anime)
    p.clearRect(0,0, innerWidth, innerHeight)
    // p.beginPath()
    // p.strokeStyle = "blue"
    // p.arc(x,y,r, 0, Math.PI * 2, false)
    // p.stroke()
    new Circle(x,y,r,dx,dy).draw()

    if (x > innerWidth - r || x < r) {
        dx = -dx
    }
    if (y > innerHeight - r || y < r) {
        dy = -dy
    }
    x += dx; 
    y += dy   
}

anime()

// for (var i=0; i <= 40; i++){
//     p.beginPath()
//     p.strokeStyle = "black"
//     p.arc(rand(window.innerWidth),rand(window.innerHeight),60, 0, Math.PI * (2/3), false)
//     p.stroke()

// }
log(drawBoard, "db")

